using UnityEngine;

namespace DeadCellsStyleUI
{
    public sealed class DeadCellsHealthBarDemo : MonoBehaviour
    {
        [SerializeField] private DeadCellsHealthBar healthBar;
        [SerializeField] private KeyCode damageKey = KeyCode.Space;
        [SerializeField] private KeyCode healKey = KeyCode.H;
        [SerializeField] private KeyCode resetKey = KeyCode.R;
        [SerializeField] private Vector2 randomDamage = new Vector2(8f, 18f);
        [SerializeField, Min(0f)] private float healAmount = 15f;

        private void Reset()
        {
            healthBar = GetComponent<DeadCellsHealthBar>();
        }

        private void Awake()
        {
            if (healthBar == null)
            {
                healthBar = GetComponent<DeadCellsHealthBar>();
            }
        }

        private void Update()
        {
            if (healthBar == null)
            {
                return;
            }

            if (Input.GetKeyDown(damageKey))
            {
                float minimum = Mathf.Min(randomDamage.x, randomDamage.y);
                float maximum = Mathf.Max(randomDamage.x, randomDamage.y);
                healthBar.Damage(Random.Range(minimum, maximum));
            }

            if (Input.GetKeyDown(healKey))
            {
                healthBar.Heal(healAmount);
            }

            if (Input.GetKeyDown(resetKey))
            {
                healthBar.SetHealth(healthBar.MaxHealth, false);
            }
        }
    }
}
