# Unity 白色掉落扣血血条

这是一个零美术资源依赖的 Unity UGUI 组件。受伤时，被扣除的整段血量先覆盖为白色，随后裂成小块向下掉落；扣血后的血量右边界会出现一次渐隐红色闪光。

## 环境

- Unity 2021.3 或更新版本
- 项目已安装 Unity UI（UGUI，通常默认存在）
- 兼容 Built-in、URP 和 HDRP，因为效果只使用 UGUI 默认材质

## 接入

1. 把整个 `DeadCellsHealthBar` 文件夹放入项目的 `Packages` 或 `Assets`。
2. 在 Canvas 下创建一个空 UI 对象，建议尺寸设为 `360 x 24`。
3. 给对象添加 `DeadCellsHealthBar` 组件。组件会自动创建背景、红色填充、碎片和闪光层。
4. 游戏扣血时调用：

```csharp
using DeadCellsStyleUI;

public class PlayerHealth : MonoBehaviour
{
    [SerializeField] private DeadCellsHealthBar healthBar;

    public void TakeDamage(float damage)
    {
        healthBar.Damage(damage);
    }
}
```

常用接口：

```csharp
healthBar.Damage(20f);                // 扣血并播放完整效果
healthBar.Heal(10f);                  // 回血，只动画红色填充
healthBar.SetHealth(75f);             // 设置血量并自动判断扣血/回血
healthBar.SetHealth(100f, false);      // 立即设置，不播放动画
healthBar.SetMaxHealth(150f, true);    // 修改上限并保持当前百分比
```

## 快速测试

在同一对象上再添加 `DeadCellsHealthBarDemo`：

- `Space`：随机扣除 8 到 18 点血
- `H`：回复 15 点血
- `R`：立即回满

## 可调参数

- `Fill Slide Duration`：红色血量收缩时间
- `Shard Rows / Shard Width`：白色扣血段的碎裂密度
- `Drop Delay`：白色段保持完整多久后开始掉落
- `Shard Lifetime / Gravity`：碎片停留时间和下坠速度
- `Horizontal Scatter / Angular Speed`：左右散射和旋转幅度
- `Flash Duration / Width / Height Multiplier`：红色边缘闪光形状与时长
- `Use Unscaled Time`：暂停或慢动作期间是否继续播放 UI 效果

## 注意

- 组件根对象以及其父对象不要添加会裁切血条外区域的 `Mask` 或 `RectMask2D`，否则向下掉落的碎片会被切掉。
- 修改组件字段后，如果生成层级出现异常，可在组件右上角菜单执行 `Rebuild Generated Visuals`。
- `Generated Visuals` 是组件维护的子层级，不要在运行时手动移动其中对象。
