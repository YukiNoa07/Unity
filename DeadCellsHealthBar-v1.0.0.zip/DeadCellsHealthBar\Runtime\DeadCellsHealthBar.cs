using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace DeadCellsStyleUI
{
    [DisallowMultipleComponent]
    [RequireComponent(typeof(RectTransform))]
    public sealed class DeadCellsHealthBar : MonoBehaviour
    {
        private const string GeneratedRootName = "Generated Visuals";

        [Header("Health")]
        [SerializeField, Min(1f)] private float maxHealth = 100f;
        [SerializeField, Min(0f)] private float currentHealth = 100f;
        [SerializeField, Min(0f)] private float fillSlideDuration = 0.1f;

        [Header("Colors")]
        [SerializeField] private Color backgroundColor = new Color(0.025f, 0.025f, 0.035f, 1f);
        [SerializeField] private Color healthColor = new Color(0.84f, 0.035f, 0.055f, 1f);
        [SerializeField] private Color flashColor = new Color(1f, 0.02f, 0.015f, 0.95f);

        [Header("Falling Damage")]
        [SerializeField, Range(1, 4)] private int shardRows = 2;
        [SerializeField, Range(4f, 24f)] private float shardWidth = 9f;
        [SerializeField, Range(1, 40)] private int maxShardColumns = 18;
        [SerializeField, Min(0f)] private float dropDelay = 0.055f;
        [SerializeField, Min(0.05f)] private float shardLifetime = 0.58f;
        [SerializeField, Min(0f)] private float gravity = 760f;
        [SerializeField, Min(0f)] private float horizontalScatter = 42f;
        [SerializeField] private Vector2 initialDownSpeed = new Vector2(25f, 80f);
        [SerializeField] private Vector2 angularSpeed = new Vector2(80f, 220f);

        [Header("Edge Flash")]
        [SerializeField, Min(0.05f)] private float flashDuration = 0.38f;
        [SerializeField, Min(1f)] private float flashWidth = 58f;
        [SerializeField, Min(1f)] private float flashHeightMultiplier = 3.1f;

        [Header("Timing")]
        [SerializeField] private bool useUnscaledTime = true;

        [Header("Generated References")]
        [SerializeField, HideInInspector] private RectTransform generatedRoot;
        [SerializeField, HideInInspector] private Image backgroundImage;
        [SerializeField, HideInInspector] private Image healthImage;
        [SerializeField, HideInInspector] private RectTransform effectsRoot;
        [SerializeField, HideInInspector] private Image edgeFlashImage;
        [SerializeField, HideInInspector] private Image edgeFlashCore;

        private readonly List<Shard> shards = new List<Shard>(40);
        private RectTransform selfRect;
        private float displayedRatio;
        private float fillTweenFrom;
        private float fillTweenTo;
        private float fillTweenTime;
        private bool fillTweenActive;
        private float flashTime = float.PositiveInfinity;

        private static Sprite glowSprite;

        public float CurrentHealth { get { return currentHealth; } }
        public float MaxHealth { get { return maxHealth; } }
        public float NormalizedHealth { get { return maxHealth <= 0f ? 0f : currentHealth / maxHealth; } }

        private sealed class Shard
        {
            public RectTransform Rect;
            public Image Image;
            public Vector2 Velocity;
            public float AngularVelocity;
            public float Age;
            public float Delay;
            public float Lifetime;
        }

        private void Reset()
        {
            selfRect = GetComponent<RectTransform>();
            maxHealth = Mathf.Max(1f, maxHealth);
            currentHealth = maxHealth;
            EnsureVisuals();
            displayedRatio = 1f;
            ApplyRatio(displayedRatio);
            SetFlashVisible(false);
        }

        private void Awake()
        {
            selfRect = GetComponent<RectTransform>();
            maxHealth = Mathf.Max(1f, maxHealth);
            currentHealth = Mathf.Clamp(currentHealth, 0f, maxHealth);
            EnsureVisuals();
            displayedRatio = NormalizedHealth;
            ApplyRatio(displayedRatio);
            SetFlashVisible(false);
        }

        private void OnValidate()
        {
            maxHealth = Mathf.Max(1f, maxHealth);
            currentHealth = Mathf.Clamp(currentHealth, 0f, maxHealth);
            shardRows = Mathf.Clamp(shardRows, 1, 4);
            maxShardColumns = Mathf.Max(1, maxShardColumns);

            if (healthImage != null && !Application.isPlaying)
            {
                displayedRatio = NormalizedHealth;
                ApplyStyle();
                ApplyRatio(displayedRatio);
            }
        }

        private void Update()
        {
            float deltaTime = useUnscaledTime ? Time.unscaledDeltaTime : Time.deltaTime;
            UpdateFill(deltaTime);
            UpdateShards(deltaTime);
            UpdateFlash(deltaTime);
        }

        public void Damage(float amount)
        {
            if (amount <= 0f)
            {
                return;
            }

            SetHealth(currentHealth - amount, true);
        }

        public void Heal(float amount)
        {
            if (amount <= 0f)
            {
                return;
            }

            SetHealth(currentHealth + amount, true);
        }

        public void SetHealth(float value, bool animate = true)
        {
            EnsureVisuals();

            float oldHealth = currentHealth;
            float newHealth = Mathf.Clamp(value, 0f, maxHealth);
            if (Mathf.Approximately(oldHealth, newHealth))
            {
                return;
            }

            currentHealth = newHealth;
            float oldRatio = oldHealth / maxHealth;
            float newRatio = newHealth / maxHealth;

            if (!animate)
            {
                fillTweenActive = false;
                displayedRatio = newRatio;
                ApplyRatio(displayedRatio);
                return;
            }

            if (newHealth < oldHealth)
            {
                SpawnDamageShards(newRatio, oldRatio);
                TriggerEdgeFlash(newRatio);
            }

            BeginFillTween(newRatio);
        }

        public void SetMaxHealth(float value, bool preservePercentage = false)
        {
            value = Mathf.Max(1f, value);
            float ratio = NormalizedHealth;
            maxHealth = value;
            currentHealth = preservePercentage
                ? maxHealth * ratio
                : Mathf.Clamp(currentHealth, 0f, maxHealth);

            fillTweenActive = false;
            displayedRatio = NormalizedHealth;
            ApplyRatio(displayedRatio);
        }

        [ContextMenu("Rebuild Generated Visuals")]
        private void RebuildGeneratedVisuals()
        {
            if (generatedRoot != null)
            {
                DestroyObject(generatedRoot.gameObject);
            }

            generatedRoot = null;
            backgroundImage = null;
            healthImage = null;
            effectsRoot = null;
            edgeFlashImage = null;
            edgeFlashCore = null;
            shards.Clear();

            EnsureVisuals();
            displayedRatio = NormalizedHealth;
            ApplyRatio(displayedRatio);
            SetFlashVisible(false);
        }

        private void EnsureVisuals()
        {
            if (selfRect == null)
            {
                selfRect = GetComponent<RectTransform>();
            }

            if (generatedRoot == null)
            {
                Transform existing = transform.Find(GeneratedRootName);
                generatedRoot = existing as RectTransform;
            }

            if (generatedRoot == null)
            {
                GameObject rootObject = new GameObject(GeneratedRootName, typeof(RectTransform));
                rootObject.layer = gameObject.layer;
                generatedRoot = rootObject.GetComponent<RectTransform>();
                generatedRoot.SetParent(transform, false);
            }

            Stretch(generatedRoot);

            backgroundImage = FindOrCreateImage("Background", generatedRoot, backgroundImage);
            Stretch(backgroundImage.rectTransform);

            healthImage = FindOrCreateImage("Health Fill", generatedRoot, healthImage);
            RectTransform healthRect = healthImage.rectTransform;
            healthRect.anchorMin = Vector2.zero;
            healthRect.anchorMax = new Vector2(displayedRatio, 1f);
            healthRect.pivot = new Vector2(0f, 0.5f);
            healthRect.offsetMin = Vector2.zero;
            healthRect.offsetMax = Vector2.zero;

            if (effectsRoot == null)
            {
                Transform existingEffects = generatedRoot.Find("Effects");
                effectsRoot = existingEffects as RectTransform;
            }

            if (effectsRoot == null)
            {
                GameObject effectsObject = new GameObject("Effects", typeof(RectTransform));
                effectsObject.layer = gameObject.layer;
                effectsRoot = effectsObject.GetComponent<RectTransform>();
                effectsRoot.SetParent(generatedRoot, false);
            }

            Stretch(effectsRoot);

            edgeFlashImage = FindOrCreateImage("Edge Flash", effectsRoot, edgeFlashImage);
            edgeFlashImage.sprite = GetGlowSprite();
            edgeFlashImage.preserveAspect = false;

            edgeFlashCore = FindOrCreateImage("Core", edgeFlashImage.rectTransform, edgeFlashCore);
            RectTransform coreRect = edgeFlashCore.rectTransform;
            coreRect.anchorMin = new Vector2(0.5f, 0.15f);
            coreRect.anchorMax = new Vector2(0.5f, 0.85f);
            coreRect.pivot = new Vector2(0.5f, 0.5f);
            coreRect.sizeDelta = new Vector2(2f, 0f);
            coreRect.anchoredPosition = Vector2.zero;

            ApplyStyle();
        }

        private void ApplyStyle()
        {
            if (backgroundImage != null)
            {
                backgroundImage.color = backgroundColor;
                backgroundImage.raycastTarget = false;
            }

            if (healthImage != null)
            {
                healthImage.color = healthColor;
                healthImage.raycastTarget = false;
            }

            if (edgeFlashImage != null)
            {
                edgeFlashImage.raycastTarget = false;
            }

            if (edgeFlashCore != null)
            {
                edgeFlashCore.raycastTarget = false;
            }
        }

        private void BeginFillTween(float targetRatio)
        {
            fillTweenFrom = displayedRatio;
            fillTweenTo = Mathf.Clamp01(targetRatio);
            fillTweenTime = 0f;
            fillTweenActive = fillSlideDuration > 0f;

            if (!fillTweenActive)
            {
                displayedRatio = fillTweenTo;
                ApplyRatio(displayedRatio);
            }
        }

        private void UpdateFill(float deltaTime)
        {
            if (!fillTweenActive)
            {
                return;
            }

            fillTweenTime += deltaTime;
            float t = Mathf.Clamp01(fillTweenTime / fillSlideDuration);
            float eased = 1f - Mathf.Pow(1f - t, 3f);
            displayedRatio = Mathf.LerpUnclamped(fillTweenFrom, fillTweenTo, eased);
            ApplyRatio(displayedRatio);

            if (t >= 1f)
            {
                fillTweenActive = false;
                displayedRatio = fillTweenTo;
            }
        }

        private void ApplyRatio(float ratio)
        {
            if (healthImage == null)
            {
                return;
            }

            RectTransform rect = healthImage.rectTransform;
            rect.anchorMax = new Vector2(Mathf.Clamp01(ratio), 1f);
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;
        }

        private void SpawnDamageShards(float newRatio, float oldRatio)
        {
            float start = Mathf.Clamp01(Mathf.Min(newRatio, oldRatio));
            float end = Mathf.Clamp01(Mathf.Max(newRatio, oldRatio));
            if (end - start <= 0.0001f)
            {
                return;
            }

            Canvas.ForceUpdateCanvases();
            float barWidth = Mathf.Max(1f, selfRect.rect.width);
            float damageWidth = barWidth * (end - start);
            int columns = Mathf.Clamp(Mathf.CeilToInt(damageWidth / shardWidth), 1, maxShardColumns);
            int rows = Mathf.Max(1, shardRows);

            for (int row = 0; row < rows; row++)
            {
                for (int column = 0; column < columns; column++)
                {
                    float x0 = Mathf.Lerp(start, end, column / (float)columns);
                    float x1 = Mathf.Lerp(start, end, (column + 1f) / columns);
                    float y0 = row / (float)rows;
                    float y1 = (row + 1f) / rows;

                    Image shardImage = CreateImage("Damage Shard", effectsRoot);
                    shardImage.color = Color.white;

                    RectTransform rect = shardImage.rectTransform;
                    rect.anchorMin = new Vector2(x0, y0);
                    rect.anchorMax = new Vector2(x1, y1);
                    rect.pivot = new Vector2(0.5f, 0.5f);
                    rect.offsetMin = Vector2.zero;
                    rect.offsetMax = Vector2.zero;

                    float downSpeed = Random.Range(
                        Mathf.Min(initialDownSpeed.x, initialDownSpeed.y),
                        Mathf.Max(initialDownSpeed.x, initialDownSpeed.y));
                    float spin = Random.Range(
                        Mathf.Min(angularSpeed.x, angularSpeed.y),
                        Mathf.Max(angularSpeed.x, angularSpeed.y));

                    shards.Add(new Shard
                    {
                        Rect = rect,
                        Image = shardImage,
                        Velocity = new Vector2(Random.Range(-horizontalScatter, horizontalScatter), -downSpeed),
                        AngularVelocity = Random.value < 0.5f ? -spin : spin,
                        Age = 0f,
                        Delay = dropDelay + Random.Range(0f, 0.045f),
                        Lifetime = shardLifetime + Random.Range(-0.06f, 0.08f)
                    });
                }
            }

            edgeFlashImage.transform.SetAsLastSibling();
        }

        private void UpdateShards(float deltaTime)
        {
            for (int i = shards.Count - 1; i >= 0; i--)
            {
                Shard shard = shards[i];
                if (shard.Rect == null)
                {
                    shards.RemoveAt(i);
                    continue;
                }

                shard.Age += deltaTime;
                if (shard.Age < shard.Delay)
                {
                    continue;
                }

                float fallAge = shard.Age - shard.Delay;
                shard.Velocity += Vector2.down * gravity * deltaTime;
                shard.Rect.anchoredPosition += shard.Velocity * deltaTime;
                shard.Rect.Rotate(0f, 0f, shard.AngularVelocity * deltaTime);

                float normalizedAge = Mathf.Clamp01(fallAge / shard.Lifetime);
                float alpha = 1f - Mathf.SmoothStep(0f, 1f, Mathf.InverseLerp(0.2f, 1f, normalizedAge));
                shard.Image.color = new Color(1f, 1f, 1f, alpha);

                float shrink = Mathf.Lerp(1f, 0.58f, normalizedAge);
                shard.Rect.localScale = new Vector3(shrink, shrink, 1f);

                if (normalizedAge >= 1f)
                {
                    DestroyObject(shard.Rect.gameObject);
                    shards.RemoveAt(i);
                }
            }
        }

        private void TriggerEdgeFlash(float ratio)
        {
            EnsureVisuals();
            flashTime = 0f;

            RectTransform rect = edgeFlashImage.rectTransform;
            float height = Mathf.Max(12f, selfRect.rect.height);
            rect.anchorMin = new Vector2(Mathf.Clamp01(ratio), 0.5f);
            rect.anchorMax = new Vector2(Mathf.Clamp01(ratio), 0.5f);
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = Vector2.zero;
            rect.sizeDelta = new Vector2(flashWidth, height * flashHeightMultiplier);
            rect.localScale = new Vector3(0.35f, 0.55f, 1f);
            rect.SetAsLastSibling();
            SetFlashVisible(true);
        }

        private void UpdateFlash(float deltaTime)
        {
            if (edgeFlashImage == null || flashTime > flashDuration)
            {
                return;
            }

            flashTime += deltaTime;
            float t = Mathf.Clamp01(flashTime / flashDuration);
            float fade = (1f - t) * (1f - t);
            float expansion = 1f - Mathf.Pow(1f - t, 3f);

            Color glow = flashColor;
            glow.a *= fade;
            edgeFlashImage.color = glow;

            Color core = Color.Lerp(Color.white, flashColor, 0.45f);
            core.a = fade;
            edgeFlashCore.color = core;

            edgeFlashImage.rectTransform.localScale = new Vector3(
                Mathf.Lerp(0.35f, 1.2f, expansion),
                Mathf.Lerp(0.55f, 1f, expansion),
                1f);

            if (t >= 1f)
            {
                SetFlashVisible(false);
                flashTime = float.PositiveInfinity;
            }
        }

        private void SetFlashVisible(bool visible)
        {
            if (edgeFlashImage != null)
            {
                edgeFlashImage.gameObject.SetActive(visible);
            }
        }

        private Image FindOrCreateImage(string childName, Transform parent, Image current)
        {
            if (current != null)
            {
                return current;
            }

            Transform existing = parent.Find(childName);
            Image existingImage;
            if (existing != null && existing.TryGetComponent(out existingImage))
            {
                return existingImage;
            }

            return CreateImage(childName, parent);
        }

        private Image CreateImage(string objectName, Transform parent)
        {
            GameObject imageObject = new GameObject(
                objectName,
                typeof(RectTransform),
                typeof(CanvasRenderer),
                typeof(Image));
            imageObject.layer = gameObject.layer;
            imageObject.transform.SetParent(parent, false);
            Image image = imageObject.GetComponent<Image>();
            image.raycastTarget = false;
            return image;
        }

        private static void Stretch(RectTransform rect)
        {
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;
        }

        private static Sprite GetGlowSprite()
        {
            if (glowSprite != null)
            {
                return glowSprite;
            }

            const int size = 64;
            Texture2D texture = new Texture2D(size, size, TextureFormat.RGBA32, false)
            {
                name = "Runtime Health Bar Glow",
                wrapMode = TextureWrapMode.Clamp,
                filterMode = FilterMode.Bilinear,
                hideFlags = HideFlags.HideAndDontSave
            };

            Color[] pixels = new Color[size * size];
            for (int y = 0; y < size; y++)
            {
                float normalizedY = Mathf.Abs((y + 0.5f) / size * 2f - 1f);
                for (int x = 0; x < size; x++)
                {
                    float normalizedX = Mathf.Abs((x + 0.5f) / size * 2f - 1f);
                    float distance = Mathf.Sqrt(normalizedX * normalizedX + normalizedY * normalizedY);
                    float alpha = Mathf.Pow(Mathf.Clamp01(1f - distance), 2.2f);
                    pixels[y * size + x] = new Color(1f, 1f, 1f, alpha);
                }
            }

            texture.SetPixels(pixels);
            texture.Apply(false, true);
            glowSprite = Sprite.Create(
                texture,
                new Rect(0f, 0f, size, size),
                new Vector2(0.5f, 0.5f),
                100f);
            glowSprite.name = "Runtime Health Bar Glow Sprite";
            glowSprite.hideFlags = HideFlags.HideAndDontSave;
            return glowSprite;
        }

        private static void DestroyObject(Object target)
        {
            if (target == null)
            {
                return;
            }

            if (Application.isPlaying)
            {
                Destroy(target);
            }
            else
            {
                DestroyImmediate(target);
            }
        }
    }
}
